#include "mainwindow.h"
#include <QUdpSocket>
#include <QNetworkDatagram>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupUi(this);

    m_socket = new QUdpSocket(this);    //erstellt UDP SOCKET
    m_socket->bind(QHostAddress::AnyIPv4, 60000);   	//nimmt Nachrichten nur über Port 60000 an

    connect(m_socket, SIGNAL(readyRead()), this, SLOT(dataAvailable()));
}

MainWindow::~MainWindow() {}


void MainWindow::dataAvailable()
{


    while (m_socket->hasPendingDatagrams())
    {
        QNetworkDatagram datagram = m_socket->receiveDatagram();

        QByteArray data = datagram.data();

        QString text = QString(data);

        textEdit_2->append(text);

    }

}
void MainWindow::on_pushButton_clicked()
{

    QByteArray byteArray = textEdit->toPlainText().toUtf8();
    QHostAddress host = QHostAddress(lineEdit->text());

    m_socket->writeDatagram(byteArray, host, 60000);

}



