#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QNetworkDatagram>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_socket(new QUdpSocket(this))
    , m_timer(new QTimer(this))
{
    ui->setupUi(this);

    if (!m_socket->bind(QHostAddress::AnyIPv4, 60000)) {
        qDebug() << "fehlgeschlagen:" << m_socket->errorString();
    }

    connect(m_socket, &QUdpSocket::readyRead, this, &MainWindow::datenbearbeiten);
    connect(m_timer, &QTimer::timeout, this, &MainWindow::automatischsenden);

    QTimer::singleShot(100, this, &MainWindow::automatischsenden);  //einmalige Verzögerung
}

MainWindow::~MainWindow()   //Merksatz! "Jedes new braucht ein delete"
{
    delete ui;
}

void MainWindow::datenbearbeiten()  //datagramm wie UDP Socket (Brief)
{
    while (m_socket->hasPendingDatagrams()) {
        QNetworkDatagram datagram = m_socket->receiveDatagram();
        QString antwort = QString(datagram.data()).trimmed();
        QString sender = datagram.senderAddress().toString();

        ui->textEdit_2->append("Antwort von " + sender + ": " + antwort);

        if (sender == spieler1_ip || sender == spieler2_ip) {
            datenerhalten(sender, antwort);  // Sender und Antwort übergeben
        }
    }
}

void MainWindow::automatischsenden()
{
    if (index < fragen.size()) {
        ui->textEdit->setText(fragen[index]);
        // An beide Spieler senden
        m_socket->writeDatagram(ui->textEdit->toPlainText().toUtf8(), QHostAddress(spieler1_ip), 60000);
        m_socket->writeDatagram(ui->textEdit->toPlainText().toUtf8(), QHostAddress(spieler2_ip), 60000);
        //Aufbau (DATEN, ZIEL_IP, PORT)
        //.toUtf8 immer bei Netzwerkkommunikation
        index++;
        m_timer->start(10000);
        ui->textEdit_2->clear();
    } else {
        ui->textEdit->append("Quiz beendet!");
        m_timer->stop();

        // Gewinner ermitteln
        QString gewinner;
        if (spieler1_punkte > spieler2_punkte) {
            gewinner = "Spieler 1 gewinnt!";
        } else if (spieler2_punkte > spieler1_punkte) {
            gewinner = "Spieler 2 gewinnt!";
        } else {
            gewinner = "Unentschieden!";
        }
        ui->textEdit_2->append("\nErgebnis:\n" + gewinner);
    }
}

void MainWindow::datenerhalten(const QString& sender, const QString& antwort)
{
    if (index > 0 && index <= antworten.size()) {
        QString richtigeAntwort = antworten[index-1];

        if (antwort.contains(richtigeAntwort, Qt::CaseInsensitive)) {   // Ignoriert Groß/Klein schreibung
            if (sender == spieler1_ip) {
                spieler1_punkte++;
                ui->textEdit_2->append("✅ Spieler1 ist richtig!");
            } else if (sender == spieler2_ip) {
                spieler2_punkte++;
                ui->textEdit_2->append("✅ Spieler2 ist richtig!");
            }
            updatePunktestand();
        } else {
            ui->textEdit_2->append("❌ Falsche Antwort von " + sender);
        }
    }
}

void MainWindow::updatePunktestand()
{
    ui->textEdit_3->setText(
        //konvertiert 3 zu "3"
        "Spieler 1: " + QString::number(spieler1_punkte) + " Punkte\n"
        "Spieler 2: " + QString::number(spieler2_punkte) + " Punkte"
        );
}
