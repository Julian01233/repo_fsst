#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QUdpSocket>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void datenbearbeiten();
    void datenerhalten(const QString& sender, const QString& antwort);
    void automatischsenden();
    void updatePunktestand();

private:
    Ui::MainWindow *ui;
    QUdpSocket *m_socket;
    QTimer *m_timer;
    int index = 0;
    int spieler1_punkte = 0;
    int spieler2_punkte = 0;
    const QString spieler1_ip = "10.0.0.21";
    const QString spieler2_ip = "10.0.0.14";
    const QStringList fragen = {
        "Was ist die Hauptstadt von Deutschland?",
        "Wie viele Kontinente gibt es?",
        "Was ist 2+2?",
        "Wer schrieb Faust?",
        "Welche Farbe hat der Himmel?"
    };
    const QStringList antworten = {
        "Berlin", "7", "4", "Goethe", "Blau"
    };
};
#endif // MAINWINDOW_H
